import { ArrowRight, MapPin, Star, Users } from 'lucide-react';
  const makers = [
    {
      id: 1,
      name: "Sarah Chen",
      location: "Portland, OR",
      specialty: "Custom Cabinets & Furniture",
      rating: 4.9,
      reviews: 127,
      followers: 2340,
      image: "https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop",
      bio: "20+ years crafting bespoke furniture with sustainable materials",
      portfolio: [
        "https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop",
        "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop",
        "https://images.pexels.com/photos/1571453/pexels-photo-1571453.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
      ]
    },
    {
      id: 2,
      name: "Marcus Rivera",
      location: "Austin, TX",
      specialty: "Live Edge Tables & Sculptures",
      rating: 4.8,
      reviews: 89,
      followers: 1876,
      image: "https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop",
      bio: "Transforming reclaimed wood into functional art pieces",
      portfolio: [
        "https://images.pexels.com/photos/1571458/pexels-photo-1571458.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop",
        "https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop",
        "https://images.pexels.com/photos/1571463/pexels-photo-1571463.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
      ]
    },
    {
      id: 3,
      name: "Elena Johansson",
      location: "Seattle, WA",
      specialty: "Children's Furniture & Toys",
      rating: 5.0,
      reviews: 203,
      followers: 3120,
      image: "https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop",
      bio: "Creating safe, beautiful furniture for the next generation",
      portfolio: [
        "https://images.pexels.com/photos/1571462/pexels-photo-1571462.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop",
        "https://images.pexels.com/photos/1571464/pexels-photo-1571464.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop",
        "https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
      ]
    }
  ];
const FeaturedMakers = () => {
    return (
         <section className="py-20 bg-white">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex justify-between items-center mb-12">
                <h2 className="text-4xl font-bold text-amber-900">Featured Makers</h2>
                <button 
                  onClick={() => setActiveView('makers')}
                  className="text-amber-700 hover:text-amber-800 font-semibold flex items-center"
                >
                  View All <ArrowRight className="w-5 h-5 ml-1" />
                </button>
              </div>
              
              <div className="grid md:grid-cols-3 gap-8">
                {makers.map((maker) => (
                  <div key={maker.id} className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-shadow">
                    <div className="flex items-center mb-4">
                      <img 
                        src={maker.image} 
                        alt={maker.name}
                        className="w-16 h-16 rounded-full object-cover mr-4"
                      />
                      <div>
                        <h3 className="font-semibold text-amber-900">{maker.name}</h3>
                        <div className="flex items-center text-sm text-gray-600">
                          <MapPin className="w-4 h-4 mr-1" />
                          {maker.location}
                        </div>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mb-4">{maker.bio}</p>
                    <div className="flex justify-between text-sm mb-4">
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-yellow-400 mr-1" />
                        {maker.rating} ({maker.reviews})
                      </div>
                      <div className="flex items-center">
                        <Users className="w-4 h-4 text-gray-400 mr-1" />
                        {maker.followers.toLocaleString()}
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      {maker.portfolio.slice(0, 3).map((img, index) => (
                        <img 
                          key={index}
                          src={img} 
                          alt="Portfolio piece"
                          className="w-full h-20 object-cover rounded-lg"
                        />
                      ))}
                    </div>
                    <button className="w-full bg-amber-700 text-white py-2 rounded-lg hover:bg-amber-800 transition-colors">
                      View Profile
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </section>
    );
};

export default FeaturedMakers;