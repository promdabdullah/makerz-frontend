import { Star } from "lucide-react";

 const testimonials = [
    {
      name: "Jennifer Walsh",
      text: "Sarah created the most beautiful kitchen island for our home. The craftsmanship is incredible and the process was seamless.",
      rating: 5,
      image: "https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop"
    },
    {
      name: "David Martinez",
      text: "Marcus transformed our living room with a stunning live edge coffee table. Couldn't be happier with the results.",
      rating: 5,
      image: "https://images.pexels.com/photos/1181562/pexels-photo-1181562.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop"
    },
    {
      name: "Amy Thompson",
      text: "Elena designed the perfect play table for our kids. Safe, beautiful, and built to last generations.",
      rating: 5,
      image: "https://images.pexels.com/photos/1181717/pexels-photo-1181717.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop"
    }
  ];
const Testimonials = () => {
    return (
          <section className="py-20 bg-white">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                <h2 className="text-4xl font-bold text-amber-900 mb-4">What Our Customers Say</h2>
                <p className="text-xl text-gray-600">
                  Real stories from people who found their perfect craftsperson
                </p>
              </div>
              
              <div className="grid md:grid-cols-3 gap-8">
                {testimonials.map((testimonial, index) => (
                  <div key={index} className="bg-gray-50 p-8 rounded-xl">
                    <div className="flex items-center mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    <p className="text-gray-700 mb-6 italic">"{testimonial.text}"</p>
                    <div className="flex items-center">
                      <img 
                        src={testimonial.image} 
                        alt={testimonial.name}
                        className="w-12 h-12 rounded-full object-cover mr-4"
                      />
                      <div>
                        <div className="font-semibold text-amber-900">{testimonial.name}</div>
                        <div className="text-sm text-gray-600">Verified Customer</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
    );
};

export default Testimonials;