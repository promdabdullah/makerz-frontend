import { ArrowRight, Heart } from "lucide-react";

 const products = [
    {
      id: 1,
      name: "Handcrafted Oak Dining Table",
      maker: "Sarah Chen",
      price: "$2,400",
      likes: 156,
      image: "https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&fit=crop",
      description: "Solid oak dining table with live edge finish, seats 6-8 people"
    },
    {
      id: 2,
      name: "Reclaimed Wood Coffee Table",
      maker: "Marcus Rivera",
      price: "$890",
      likes: 203,
      image: "https://images.pexels.com/photos/1571458/pexels-photo-1571458.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&fit=crop",
      description: "Unique coffee table made from 100-year-old barn wood"
    },
    {
      id: 3,
      name: "Custom Children's Bookshelf",
      maker: "Elena Johansson",
      price: "$320",
      likes: 89,
      image: "https://images.pexels.com/photos/1571462/pexels-photo-1571462.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&fit=crop",
      description: "Safe, colorful bookshelf designed to grow with your child"
    }
  ];

const FeaturedProducts = () => {
    return (
       <section className="py-20 bg-amber-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex justify-between items-center mb-12">
                <h2 className="text-4xl font-bold text-amber-900">Featured Products</h2>
                <button 
                  onClick={() => setActiveView('products')}
                  className="text-amber-700 hover:text-amber-800 font-semibold flex items-center"
                >
                  View All <ArrowRight className="w-5 h-5 ml-1" />
                </button>
              </div>
              
              <div className="grid md:grid-cols-3 gap-8">
                {products.map((product) => (
                  <div key={product.id} className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                    <div className="relative">
                      <img 
                        src={product.image} 
                        alt={product.name}
                        className="w-full h-64 object-cover"
                      />
                      <button className="absolute top-4 right-4 bg-white p-2 rounded-full shadow-lg hover:bg-gray-50">
                        <Heart className="w-5 h-5 text-gray-600" />
                      </button>
                    </div>
                    <div className="p-6">
                      <h3 className="font-semibold text-amber-900 mb-2">{product.name}</h3>
                      <p className="text-sm text-gray-600 mb-3">{product.description}</p>
                      <div className="flex justify-between items-center mb-4">
                        <span className="text-2xl font-bold text-amber-700">{product.price}</span>
                        <div className="flex items-center text-sm text-gray-600">
                          <Heart className="w-4 h-4 mr-1" />
                          {product.likes}
                        </div>
                      </div>
                      <div className="text-sm text-gray-600 mb-4">by {product.maker}</div>
                      <button className="w-full bg-amber-700 text-white py-2 rounded-lg hover:bg-amber-800 transition-colors">
                        Contact Maker
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
    );
};

export default FeaturedProducts;