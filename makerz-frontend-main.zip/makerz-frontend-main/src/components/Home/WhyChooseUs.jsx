import { Award, Handshake, Shield } from 'lucide-react';
import React, { useEffect } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css';

const WhyChooseUs = () => {
      useEffect(() => {
    AOS.init({ duration: 1000});
  }, []);
    return (
         <section className="py-20 bg-gradient-to-br from-amber-50 to-orange-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-amber-900 mb-4">Why Choose Luxury Furniture and Electronics</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We connect you with master craftspeople who share your passion for quality and authenticity
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow" data-aos="fade-up">
            <Award className="w-12 h-12 text-amber-700 mb-6" />
            <h3 className="text-xl font-semibold text-amber-900 mb-4">Master Craftsmanship</h3>
            <p className="text-gray-600">
              Our vetted artisans bring decades of experience and passion to every piece they create. 
              Each maker is carefully selected for their skill and dedication to quality.
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow" data-aos="fade-up" data-aos-delay="200">
            <Shield className="w-12 h-12 text-amber-700 mb-6" />
            <h3 className="text-xl font-semibold text-amber-900 mb-4">Trust & Security</h3>
            <p className="text-gray-600">
              Secure payments, verified makers, and comprehensive project protection. 
              Our platform ensures a safe and reliable experience for both customers and artisans.
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow" data-aos="fade-up" data-aos-delay="400">
            <Handshake className="w-12 h-12 text-amber-700 mb-6" />
            <h3 className="text-xl font-semibold text-amber-900 mb-4">Personal Connection</h3>
            <p className="text-gray-600">
              Work directly with the craftsperson who will create your piece. Build relationships 
              and be part of the creative process from start to finish.
            </p>
          </div>
        </div>
      </div>
    </section>
    );
};

export default WhyChooseUs;