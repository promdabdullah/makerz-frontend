import { ArrowRight } from "lucide-react";
import { useState } from "react";
import AuthModal from "../ui/AuthModal";

const HeroSection = () => {
    const [showAuthModal, setShowAuthModal] = useState(false);
    
    return (
        
          <section className="bg-gradient-to-br from-amber-50 to-orange-50 py-20">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid lg:grid-cols-2 gap-12 items-center">
                <div>
                  <h1 className="text-5xl lg:text-6xl font-bold text-amber-900 leading-tight mb-6">
                    Custom Wood
                    <br />
                    <span className="text-amber-700">Crafted with Care</span>
                  </h1>
                  <p className="text-xl text-gray-700 mb-8 leading-relaxed">
                    Connect with skilled woodworkers and artisans to bring your vision to life. 
                    From custom furniture to unique home decor, find the perfect craftsperson for your project.
                  </p>
                  <div className="space-y-4 sm:space-y-0 sm:space-x-4 sm:flex">
                    <button 
                      onClick={() => setShowAuthModal(true)}
                      className="w-full sm:w-auto bg-amber-700 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-amber-800 transition-all transform hover:scale-105 shadow-lg"
                    >
                      Are you a maker? Register now
                    </button>
                    <button 
                      onClick={() => setActiveView('makers')}
                      className="w-full sm:w-auto border-2 border-amber-700 text-amber-700 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-amber-50 transition-colors flex items-center justify-center"
                    >
                      Explore Makers <ArrowRight className="w-5 h-5 ml-2" />
                    </button>
                  </div>
                </div>
                <div className="relative">
                  <img 
                    src="https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=600&h=500&fit=crop"
                    alt="Beautiful wooden furniture"
                    className="rounded-2xl shadow-2xl"
                  />
                  <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-lg">
                    <div className="text-2xl font-bold text-amber-900">500+</div>
                    <div className="text-gray-600">Skilled Makers</div>
                  </div>
                </div>
              </div>
            </div>
                 {showAuthModal && <AuthModal showAuthModal={showAuthModal} setShowAuthModal={setShowAuthModal} />}
          </section>
    );
};

export default HeroSection;