import { CheckCircle, MessageSquare, Search } from "lucide-react";

import AOS from "aos";
import "aos/dist/aos.css";
import { useEffect } from "react";


const HowItWorks = () => {
    useEffect(() => {
      AOS.init({ duration: 1000 });
    }, []);
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-amber-900 mb-4">
            How It Works
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From concept to creation, we make it simple to connect with skilled
            craftspeople
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="text-center group" data-aos="fade-up">
            <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-amber-200 transition-colors">
              <Search className="w-8 h-8 text-amber-700" />
            </div>
            <h3 className="text-xl font-semibold text-amber-900 mb-4">
              1. Discover & Browse
            </h3>
            <p className="text-gray-600">
              Explore profiles of talented woodworkers and artisans. View their
              portfolios, read reviews, and find the perfect match for your
              project.
            </p>
          </div>

          <div
            className="text-center group"
            data-aos="fade-up"
            data-aos-delay="200"
          >
            <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-amber-200 transition-colors">
              <MessageSquare className="w-8 h-8 text-amber-700" />
            </div>
            <h3 className="text-xl font-semibold text-amber-900 mb-4">
              2. Connect & Collaborate
            </h3>
            <p className="text-gray-600">
              Post your project brief or contact makers directly. Discuss your
              vision, materials, timeline, and get a personalized quote.
            </p>
          </div>

          <div
            className="text-center group"
            data-aos="fade-up"
            data-aos-delay="400"
          >
            <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-amber-200 transition-colors">
              <CheckCircle className="w-8 h-8 text-amber-700" />
            </div>
            <h3 className="text-xl font-semibold text-amber-900 mb-4">
              3. Create & Deliver
            </h3>
            <p className="text-gray-600">
              Watch your custom piece come to life. Receive updates throughout
              the process and enjoy your handcrafted furniture or decor.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
