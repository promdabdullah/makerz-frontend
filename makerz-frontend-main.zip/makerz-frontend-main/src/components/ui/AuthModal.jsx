import { X } from "lucide-react";

 const AuthModal = ({setShowAuthModal }) => (
  <div style={{zIndex:999}} className="fixed  inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 ">
    <div className="bg-white rounded-2xl p-8 max-w-md w-full">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-amber-900">Join Luxury Furniture and Electronics</h2>
        <button onClick={() => setShowAuthModal(false)}>
          <X className="w-6 h-6 text-gray-500" />
        </button>
      </div>
      <div className="space-y-4">
        <button className="w-full bg-amber-700 text-white py-3 rounded-lg hover:bg-amber-800 transition-colors">
          Register as a Maker
        </button>
        <button className="w-full border-2 border-amber-700 text-amber-700 py-3 rounded-lg hover:bg-amber-50 transition-colors">
          Register as a Customer
        </button>
        <div className="text-center text-gray-600 py-2">
          Already have an account?{" "}
          <button className="text-amber-700 hover:underline">Sign in</button>
        </div>
      </div>
    </div>
  </div>
);
export default AuthModal;