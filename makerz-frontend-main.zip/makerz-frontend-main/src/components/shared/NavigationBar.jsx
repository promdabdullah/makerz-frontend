import { Menu, X } from "lucide-react";
import { useState } from "react";
import AuthModal from "../ui/AuthModal";


const NavigationBar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeView, setActiveView] = useState("home");
  const [showAuthModal, setShowAuthModal] = useState(false);

  return (
    <header className="bg-white shadow-sm sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="text-2xl font-bold text-amber-900">Luxury Furniture and Electronics</div>
          </div>

          <nav className="hidden md:flex space-x-8">
            <button
              onClick={() => setActiveView("home")}
              className="text-gray-700 hover:text-amber-700 transition-colors"
            >
              Home
            </button>
            <button
              onClick={() => setActiveView("makers")}
              className="text-gray-700 hover:text-amber-700 transition-colors"
            >
              Explore Makers
            </button>
            <button
              onClick={() => setActiveView("products")}
              className="text-gray-700 hover:text-amber-700 transition-colors"
            >
              Explore Products
            </button>
            <button
              onClick={() => setActiveView("blog")}
              className="text-gray-700 hover:text-amber-700 transition-colors"
            >
              Blog
            </button>
            <button className="text-gray-700 hover:text-amber-700 transition-colors">
              Post a Brief
            </button>
          </nav>

          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowAuthModal(true)}
              className="bg-amber-700 text-white px-4 py-2 rounded-lg hover:bg-amber-800 transition-colors"
            >
              Register / Login
            </button>
            <button
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t">
          <div className="px-4 py-2 space-y-2">
            <button
              onClick={() => {
                setActiveView("home");
                setIsMenuOpen(false);
              }}
              className="block w-full text-left py-2 text-gray-700 hover:text-amber-700"
            >
              Home
            </button>
            <button
              onClick={() => {
                setActiveView("makers");
                setIsMenuOpen(false);
              }}
              className="block w-full text-left py-2 text-gray-700 hover:text-amber-700"
            >
              Explore Makers
            </button>
            <button
              onClick={() => {
                setActiveView("products");
                setIsMenuOpen(false);
              }}
              className="block w-full text-left py-2 text-gray-700 hover:text-amber-700"
            >
              Explore Products
            </button>
            <button
              onClick={() => {
                setActiveView("blog");
                setIsMenuOpen(false);
              }}
              className="block w-full text-left py-2 text-gray-700 hover:text-amber-700"
            >
              Blog
            </button>
            <button className="block w-full text-left py-2 text-gray-700 hover:text-amber-700">
              Post a Brief
            </button>
          </div>
        </div>
      )}
      {showAuthModal && <AuthModal showAuthModal={showAuthModal} setShowAuthModal={setShowAuthModal} />}
    </header>
  );
};

export default NavigationBar;
