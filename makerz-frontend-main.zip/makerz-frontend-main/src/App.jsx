import AppRoutes from "./routes/web";

function App() {
  return (
    <div className="min-h-screen bg-cream-50">
      <AppRoutes/>
    </div>
  );
}

export default App;
