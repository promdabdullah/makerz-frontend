import React from 'react';
import HeroSection from '../../components/Home/HeroSection';
import HowItWorks from '../../components/Home/HowItWorks';
import WhyChooseUs from '../../components/Home/WhyChooseUs';
import FeaturedProducts from '../../components/Home/FeaturedProducts';
import Testimonials from '../../components/Home/Testimonials';
import FeaturedMakers from '../../components/Home/FeaturedMakers';

const Home = () => {
    return (
    <main>
      <section>
        <HeroSection/>
      </section>
      <section>
        <HowItWorks/>
      </section>
      <section>
        <WhyChooseUs/>
      </section>
      <section>
        <FeaturedMakers/>
      </section>
      <section>
        <FeaturedProducts/>
      </section>
      <section>
        <Testimonials/>
      </section>
    </main>
    );
};

export default Home;