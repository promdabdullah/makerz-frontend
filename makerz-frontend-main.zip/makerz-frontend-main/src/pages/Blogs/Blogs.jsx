
  const blogPosts = [
    {
      id: 1,
      title: "Choosing the Right Wood for Your Custom Furniture",
      excerpt: "A comprehensive guide to understanding different wood types and their best applications...",
      date: "March 15, 2024",
      author: "Luxury Furniture and Electronics Team",
      image: "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop"
    },
    {
      id: 2,
      title: "Sustainable Woodworking: Eco-Friendly Practices",
      excerpt: "Learn how our featured makers are leading the way in environmentally conscious craftsmanship...",
      date: "March 10, 2024",
      author: "Sarah Chen",
      image: "https://images.pexels.com/photos/1571463/pexels-photo-1571463.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop"
    },
    {
      id: 3,
      title: "The Art of Live Edge Furniture",
      excerpt: "Discover the unique beauty and craftsmanship behind live edge wood pieces...",
      date: "March 5, 2024",
      author: "Marcus Rivera",
      image: "https://images.pexels.com/photos/1571458/pexels-photo-1571458.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop"
    }
  ];
const Blogs = () => {
    return (
      <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h1 className="text-4xl font-bold text-amber-900 mb-4">Luxury Furniture and Electronics Blog</h1>
              <p className="text-xl text-gray-600">
                Tips, trends, and insights from the world of custom woodworking
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {blogPosts.map((post) => (
                <article key={post.id} className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-6">
                    <div className="flex items-center text-sm text-gray-600 mb-3">
                      <Calendar className="w-4 h-4 mr-2" />
                      {post.date}
                    </div>
                    <h2 className="text-xl font-semibold text-amber-900 mb-3">{post.title}</h2>
                    <p className="text-gray-600 mb-4">{post.excerpt}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">By {post.author}</span>
                      <button className="text-amber-700 hover:text-amber-800 font-semibold flex items-center">
                        Read More <ArrowRight className="w-4 h-4 ml-1" />
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>
    );
};

export default Blogs;