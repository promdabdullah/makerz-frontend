import { Outlet } from "react-router-dom";
import NavigationBar from "../components/shared/NavigationBar";
import Footer from "../components/shared/Footer";

const MainLayout = () => {
    return (
        <main>
            <NavigationBar/>
            <Outlet/>
            <Footer/>
        </main>
    );
};

export default MainLayout;